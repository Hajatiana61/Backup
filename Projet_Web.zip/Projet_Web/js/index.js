
let inscrit = document.querySelector(".")
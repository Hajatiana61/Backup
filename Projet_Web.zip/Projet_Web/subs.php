<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Event Add</title>
</head>
<body style="background-color:gray;">

	<form action="home.php" method="get">
	 	 <fieldset>
			  <br><br>
			  <legend>Add new event</legend>
			  <label for="Titre">Titre: </label>
			  <input type="text" id="Titre" name="Title" data-default="No-name" placeholder="Nom de l'évenement">
			  <br><br>
			  <label for="start">Event start : </label>
			  <input type="date" id="start" name="Start" required>
			  <label for="heure">Horaire : </label>
			  <input type="time" id="time_S" name="H_Start" required>
			  <br><br>
			  <label for="start">Event end : </label>
			  <input type="date" id="end" name="End" required>
			  <label for="heure">Horaire : </label>
			  <input type="time" id="time_E" name="H_End" required>
			  <br><br>
			  <label for="rotate">Repétition : </label>
			  <select id="rotate" name="rotate">
				  <option value="1">Une seule fois</option>
				  <option value="2">Tous les jours</option>
				  <option value="3">Tous les semaines</option>
				  <option value="4">Tous les mois</option>
				  <option value="5">Tous les ans</option>
			</select>
			<a style="margin-left: 10q;" href="Perso.html">Personnaliser...</a>
			<br><br>
			<label for="color">Color : </label>
			<input type="color" id="color" name="color" required>
			<label for="commit">Commit : </label>
			<input type="tex*" id="commit" name="commit" data-default="No-description" placeholder="Description text...">
			<br><br><br><br>
			<input style="margin-right: 10q;float: right;" type="submit" value="ADD" >
			<button style="float: right; margin-right: 10q;" onclick="cancel()"> Cancel </button>
		</fieldset>
	</form>

	<script>
		function cancel(){
			window.location.href = "MyServlet";
		}
	</script>

</body>
</html>

<style>
	form {
		margin-top: 100q;
	  display: flex; /* Make the form a flex container */
	  justify-content: center; /* Center horizontally */
	  align-items: center; /* Center vertically (optional) */
	}
</style>

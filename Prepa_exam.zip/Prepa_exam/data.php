<?php

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['nom']) && isset($data['email']) && isset($data['message'])) {
    // Traiter les données du formulaire
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}

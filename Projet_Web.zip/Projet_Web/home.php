<!DOCTYPE HTML>

<?php
    $column = 3;
    $anime = [

        ["title"=> "Kuruko no basket", "img"=> "./assets/anime/kuroko.jpeg", "trailer"=> "#", "stream"=> "#"],
        ["title"=> "Demon slayer", "img"=> "./assets/anime/demon.jpeg", "trailer"=> "#", "stream"=> "#"],
        ["title"=> "Blue Lock", "img"=> "./assets/anime/blue.jpeg", "trailer"=> "#", "stream"=> "#"],
        ["title"=> "Solo levling", "img"=> "./assets/anime/solo.jpeg", "trailer"=> "#", "stream"=> "#"],
        ["title"=> "Fulmetal Alchimist", "img"=> "./assets/anime/fulmetal2.jpeg", "trailer"=> "#", "stream"=> "#"],
        ["title"=> "Attack on the Titan", "img"=> "./assets/anime/titan3.jpeg", "trailer"=> "#", "stream"=> "#"],
        ["title"=> "Hunter X Hunter", "img"=> "./assets/anime/hunter.jpeg", "trailer"=> "#", "stream"=> "#"],
        ["title"=> "Jujutsu Kaisen", "img"=> "./assets/anime/jujutsu2.jpeg", "trailer"=> "#", "stream"=> "#"],
        ["title"=> "Kuruko no basket", "img"=> "./assets/anime/mashle.jpeg", "trailer"=> "#", "stream"=> "#"],
            
    ];

    $line = (count($anime) / $column);
    

?>
<HTML>
<HEAD>
    <TITLE>index boom</TITLE>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" href="./bootstrap/css/bootstrap.min.css" />
    

</HEAD>
<BODY>
    <div class="container-fluid">
        <main>
            <div class="grid-container" id="header">
                <div class="menu" id="menu-div">
                    <a href="#"><button class="menu-btn"></button></a>
                </div>
                <div id="title-div">
                    <h1>boom view <?php echo $line;?></h1>
                </div>
                <div id="user-div">
                    <div class="user-status" ><h3>?</h3></div>
                    <div class="user-name" ><h2>user</h2></div>
                </div>
                <div id="login-div">
                    <a href="#"><button class="login-btn">log out</button></a>
                </div>
            </div>
            
            <div class="home-div">

                <div class="row pt-3">
                    <nav class="navbar navbar-expand-xl navbar-dark bg-dark">
                        <div class="container-fluid">
                            <a class="navbar-brand" href="#">Navbar</a>
                            <div class="collapse navbar-collapse show" id="navbarDark">
                            <ul class="navbar-nav me-auto mb-2 mb-xl-0">
                                <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Home</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="#">Features</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                                </li>
                            </ul>
                            <form class="d-flex">
                                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                                <button class="btn btn-outline-light" type="submit">Search</button>
                            </form>
                            </div>
                        </div>
                    </nav>
                </div>
                                    <!-- List of all views -->

                <?php
                $rank = 0;
                for($i = 0; $i < $line; $i++){?>
                    <div class="row pt-3">
                        <?php  for($c = 0; $c < $column; $c++){?>
                            <div class="col">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo $anime[$rank]["title"]?></h5>
                                        <div class="div-img">
                                            <img src="<?php echo $anime[$rank]["img"]?>" class="card-img-top" alt="card-img-top">
                                        </div>
                                    </div>
                                    <div class="card-footer text-muted">
                                        
                                        <a href="#" class="btn btn-danger">Trailer</a>
                                    </div>
                                </div>
                            </div>
                        <?php $rank++;}?>
                <?php } ?>
            </div>
        </main>
        
        <footer>
        <div class="columns" id="footer">
                <div id="col1"> 
                    <p>Contact : 01 204 12 101 </p>
                    <p>assets: ####</p>
                </div>
                <div id="col2"> 
                    <p>Link : https://boom-view.com/ </p>
                    <p>copyright.@ mit.mg</p>
                </div>
                <div id="col3"> 
                    <p>Partenaria : </p>
                </div> 
            </div>
        </footer>
    </div>

    <script src="./bootstrap/js/bootstrap.bundle.min.js"></script>
</BODY>
</HTML>

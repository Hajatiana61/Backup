

document.getElementById('infoCard').addEventListener('submit', function(e){
    e.preventDefault();
    
    const string = document.getElementById('name').value;
    const reversedString = reverse(string);

    console.log(reversedString);

})

function reverse(str){
    return str.split('').reverse().join('');
}

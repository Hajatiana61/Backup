
<!DOCTYPE html>
<html>
    <head>
        <title>error adding</title>
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">

    </head>
    <body>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 bg-secondary">
                    <H2 class="text-center"> Whoops !!! </H2>
                </div>
            </div>
            <div class="row pt-5 mt-5">
                <div class="col-md-8 offset-md-2 card">
                    <div class="card-header">
                        <span class="badge bg-warning text-dark">Error found</span>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Attention</h5>
                        <p class="card-text">error: <?= $msg ?></p>
                        <a href="addData" class="btn btn-primary">return</a>
                    </div>
                    <div class="card-footer text-muted">
                        press return
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>

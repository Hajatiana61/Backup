<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<title>Document</title>-->
	<title>DHCP - NETFILTER</title>
    <link rel="stylesheet" href="./index.css">
</head>
<body>
    <section class="home">
        <div class="home-left">
            <img src="./assets/Dchp.svg" alt="">
            <a href="./dhcp" class="lien">Configure DHCP</a>
        </div>
        <div class="home-right">
            <img src="./assets/firewall.png" alt="" width="50%">
            <a href="./netfilter" class="lien">Configure NETFILTER</a>
        </div>
    </section>
</body>
</html>
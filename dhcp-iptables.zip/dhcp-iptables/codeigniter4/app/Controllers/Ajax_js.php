<?php
namespace App\Controllers;

class Ajax_js extends BaseController {

    public function execute_bash() {
        shell_exec("sudo iptables-restore < ./file/iptables.rules");   // Exécuter le script Bash   
    }

    public function saveTables(): void {
        $command = 'sudo iptables-save > ./file/iptables.rules';
        exec($command);
    }

}

document.getElementById('Add').addEventListener('submit' , function(e){
    e.preventDefault();

    const bookData = {
        'titre' : document.getElementById('titre').value,
        'auteur' : document.getElementById('auteur').value,
        'isbn' : document.getElementById('isbn').value,
        'img' : document.getElementById('img').value,
        'editeur' : document.getElementById('editeur').value,
        'date' : document.getElementById('date').value,
        'genre' : document.getElementById('genre').value,
        'intro' : document.getElementById('intro').value,
        'lang' : document.getElementById('lang').value,
        'page' : document.getElementById('page').value,
        'dispo' : document.getElementById('dispo').value,
        'etat' : document.getElementById('etat').value,
        'place' : document.getElementById('place').value
    }

    alert('les données sont enregistrées ');
    // console.log(bookData.auteur);   
});


document.addEventListener('DOMContentLoaded' , function(){

    fetch("./asset/book.json")
        .then(respo => {
            return respo.json();
        })
        .then(data => {
            
        const getData = data.books;

        const container = document.getElementById('bookList'); 
        
        var index = 0;
        for(const element of getData){
            
            const field = document.createElement('div');
            const img = document.createElement('img');
            const bttField = document.createElement('div');
            const headField = document.createElement('div');
            const parag = document.createElement('p');
            const btnField = document.createElement('div');
            const btn = document.createElement('button');

            field.setAttribute('class', 'bookContainer');
            img.setAttribute('id', 'imgList');
            img.setAttribute('src', element.image);
            img.setAttribute('alt', 'image');
            bttField.setAttribute('class', 'bottom');
            headField.setAttribute('id', 'head');
            parag.textContent = element.titre;
            btnField.setAttribute('id', 'button');
            btn.textContent = 'Detail';
            btn.setAttribute('class', 'Detail');
            btn.setAttribute('id', 'Detail'+index);


            btnField.appendChild(btn);
            headField.appendChild(parag);
            bttField.appendChild(headField);
            bttField.appendChild(btnField);
            field.appendChild(img);
            field.appendChild(bttField);
            container.appendChild(field);

            document.getElementById('Detail'+index).addEventListener('click', function(){
            
                const Detail = document.getElementById('bookInfo');
                
                Detail.innerHTML = "<div id=\"imgView\"><img id=\"imgList\" src="+element.image+" alt=\"image\"></div>"
                                    +"<div id=\"Info\">"
                                        +"<small>"
                                            +"<p>Titre: "+element.titre+"</p>"
                                            +"<p>Auteurs: "+element.auteurs+"</p>"
                                            +"<p>Date de publication: "+element.datePublication+"</p>"
                                        +"</small>"
                                    +"</div>";
            
            });

            index = index + 1;
        }

    })
    
});




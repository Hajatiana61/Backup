const formulaire = document.querySelector('#infoCard');

formulaire.addEventListener('submit', function(e) {
    e.preventDefault();

    const nom = document.querySelector('#name').value;
    const email = document.querySelector('#email').value;
    const message = document.querySelector('#message').value;

    const data = {
        nom: nom,
        email: email,
        message: message
    };

    fetch('./data.php', {
        method: 'POST', // La méthode est définie sur 'POST' pour envoyer des données
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(response => response.json())
        .then(data => {
            console.log(data);
            if (data.success) {
                alert('Formulaire envoyé avec succès!');
            } else {
                alert('Erreur lors de l\'envoi du formulaire.');
            }
        })
        .catch(error => {
            console.error(error);
            alert('Une erreur est survenue.');
        });
});
